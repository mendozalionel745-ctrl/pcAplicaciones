import axios from 'axios';

/**
 * @summary Infrastructure service to consume the Recipes API.
 * @author u202417433 -  Lionel Snayder Mendoza Machoa
 */
const http = axios.create({
    baseURL: 'https://api.sampleapis.com/recipes'
});

export class RecipeApiService {
    /**
     * Fetches the list of all recipes from the API.
     * @returns {Promise} Promise containing the GET request response.
     */
    getAllRecipes() {
        return http.get('/recipes');
    }
}