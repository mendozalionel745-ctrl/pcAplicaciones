import { Recipe } from '../../domain/model/recipe.entity.js';

/**
 * @summary Assembler to transform API data  into Domain Entities .
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
export class RecipeAssembler {
    /**
     * Transforms a JSON object from the API into a clean Recipe instance.
     * @param {Object} data - JSON object from the API.
     * @returns {Recipe} Instance of the Recipe entity.
     */
    static toDomainObject(data) {
        let parsedTags = [];
        if (typeof data.tags === 'string') {
            parsedTags = data.tags.split(',').map(tag => tag.trim());
        } else if (Array.isArray(data.tags)) {
            parsedTags = data.tags;
        }

        return new Recipe(
            data.title,
            data.photoUrl,
            data.cuisine,
            data.publicUrl,
            parsedTags,
            data.course,
            data.prepTime
        );
    }
}