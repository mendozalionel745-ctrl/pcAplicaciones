/**
 * @summary Domain entity representing a Recipe.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
export class Recipe {
    /**
     * @param {string} title - The title of the recipe.
     * @param {string} photoUrl - URL of the recipe's image.
     * @param {string} cuisine - Type of cuisine
     * @param {string} publicUrl - Public URL of the recipe.
     * @param {Array<string>} tags - Array of tags associated with the recipe.
     * @param {string} course - Course category to show as extra info.
     * @param {string} prepTime - Preparation time to show as extra info.
     */
    constructor(title, photoUrl, cuisine, publicUrl, tags, course, prepTime) {
        this.title = title;
        this.photoUrl = photoUrl;
        this.cuisine = cuisine;
        this.publicUrl = publicUrl;
        this.tags = tags;
        this.course = course;
        this.prepTime = prepTime;
    }
}