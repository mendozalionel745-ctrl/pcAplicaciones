<template>

  <pv-card class="m-2 shadow-4 h-full flex flex-column" aria-label="Recipe Card">

    <!-- Imagen en la parte superior -->
    <template #header>
      <img :src="recipe.photoUrl" :alt="recipe.title" style="width: 100%; height: 250px; object-fit: cover; border-top-left-radius: 6px; border-top-right-radius: 6px;" />
    </template>

    <template #title>
      {{ recipe.title }}
    </template>

    <template #subtitle>
      {{ recipe.cuisine }}
    </template>

    <template #content>

      <p class="m-0 mb-2"><strong>Course Category:</strong> {{ recipe.course }}</p>
      <p class="m-0"><strong>Preparation Time:</strong> {{ recipe.prepTime }} minutes</p>
    </template>

    <template #footer>

      <div class="flex flex-wrap justify-content-between align-items-center mt-auto gap-3">

        <a :href="recipe.publicUrl" target="_blank" rel="noopener noreferrer" style="text-decoration: none;">
          <pv-button :label="$t('recipeBook.goToRecipe')" severity="secondary" />
        </a>


        <div class="flex gap-2 flex-wrap">
          <pv-tag v-for="(tag, index) in recipe.tags" :key="index" :value="tag" severity="info" />
        </div>
      </div>
    </template>
  </pv-card>
</template>

<script setup>
/**
 * @summary Component to display a single recipe card.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
import { defineProps } from 'vue';
import { Recipe } from '../../domain/model/recipe.entity.js';


const props = defineProps({
  recipe: {
    type: Recipe,
    required: true
  }
});
</script>