<template>
  <div class="recipe-book-container" aria-label="Recipe Book Section">

    <h2 class="text-center my-4 text-4xl text-primary">{{ $t('recipeBook.title') }}</h2>


    <div class="grid">
      <div class="col-12 md:col-6" v-for="(recipe, index) in recipes" :key="index">
        <recipe-card :recipe="recipe" />
      </div>
    </div>
  </div>
</template>

<script setup>
/**
 * @summary Component that fetches and displays the list of recipes.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
import { ref, onMounted } from 'vue';
import { RecipeApiService } from '../../infrastructure/services/recipe-api.service.js';
import { RecipeAssembler } from '../../application/transform/recipe.assembler.js';
import RecipeCard from './recipe-card.component.vue';

const recipes = ref([]);
const recipeApi = new RecipeApiService();

onMounted(async () => {
  try {
    const response = await recipeApi.getAllRecipes();

    recipes.value = response.data.map(item => RecipeAssembler.toDomainObject(item));
  } catch (error) {
    console.error('Error fetching recipes:', error);
  }
});
</script>