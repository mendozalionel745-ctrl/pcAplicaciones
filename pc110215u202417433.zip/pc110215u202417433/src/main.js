import { createApp } from 'vue'
import App from './App.vue'
import { createI18n } from 'vue-i18n'


import PrimeVue from 'primevue/config';
import 'primevue/resources/themes/md-light-indigo/theme.css';
import 'primevue/resources/primevue.min.css';
import 'primeflex/primeflex.css';


import Toolbar from 'primevue/toolbar';
import Card from 'primevue/card';
import Button from 'primevue/button';
import Tag from 'primevue/tag';
import SelectButton from 'primevue/selectbutton';


import en from './locales/en.json';
import es from './locales/es.json';


const i18n = createI18n({
    legacy: false,
    locale: 'en',
    fallbackLocale: 'en',
    messages: { en, es }
});

const app = createApp(App);

app.use(PrimeVue);
app.use(i18n);


app.component('pv-toolbar', Toolbar);
app.component('pv-card', Card);
app.component('pv-button', Button);
app.component('pv-tag', Tag);
app.component('pv-selectbutton', SelectButton);

app.mount('#app')