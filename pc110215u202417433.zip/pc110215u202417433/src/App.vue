<template>
  <div class="app-layout">

    <toolbar-content />

    <main class="main-content container mx-auto px-4">

      <recipe-book />
    </main>


    <footer-content />
  </div>
</template>

<script setup>
/**
 * @summary Main application component.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
import ToolbarContent from './shared/presentation/components/toolbar-content.component.vue';
import FooterContent from './shared/presentation/components/footer-content.component.vue';
import RecipeBook from './recipes/presentation/components/recipe-book.component.vue';
</script>

<style>
body {
  margin: 0;
  padding: 0;
  font-family: 'Roboto', 'Segoe UI', sans-serif;
  background-color: #f8f9fa;
}
.app-layout {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.main-content {
  flex: 1;
  max-width: 1200px;
}
</style>