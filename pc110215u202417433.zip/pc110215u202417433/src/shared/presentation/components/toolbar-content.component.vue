<template>
  <pv-toolbar aria-label="Main Application Toolbar" class="mb-4 shadow-2">
    <template #start>
      <div class="flex align-items-center gap-3">

        <img
            src="https://img.logo.dev/plantoeat.com?token=pk_SkUbEQNLTL-lStLHcjer5A&retina=true"
            alt="Plan to Eat Logo"
            style="height: 40px; border-radius: 8px;"
        />

        <h1 class="text-2xl m-0 font-bold text-primary">{{ $t('toolbar.title') }}</h1>
      </div>
    </template>

    <template #end>

      <pv-selectbutton
          v-model="$i18n.locale"
          :options="languages"
          aria-label="Language Selector"
          class="p-button-sm"
      />
    </template>
  </pv-toolbar>
</template>

<script setup>
/**
 * @summary Toolbar component containing the logo, title, and language selector.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
import { ref } from 'vue';


const languages = ref(['en', 'es']);
</script>