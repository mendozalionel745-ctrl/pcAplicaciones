<template>
  <footer class="surface-ground text-center p-4 mt-5 border-top-1 surface-border" aria-label="Application Footer">

    <p class="m-0 mb-2 font-medium">{{ $t('footer.copyright') }}</p>

    <p class="m-0 text-color-secondary">
      {{ $t('footer.developedBy') }}: u202417433 - Lionel Snayder Mendoza Machoa
    </p>
  </footer>
</template>

<script setup>
/**
 * @summary Footer component displaying copyright and developer information.
 * @author u202417433 - Lionel Snayder Mendoza Machoa
 */
</script>